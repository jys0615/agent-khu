# 아키텍처 📐

Agent KHU의 시스템 아키텍처를 상세히 설명합니다.

---

## 📋 목차

- [전체 구조](#전체-구조)
- [Agentic AI 워크플로우](#agentic-ai-워크플로우)
- [MCP 프로토콜](#mcp-프로토콜)
- [백엔드 아키텍처](#백엔드-아키텍처)
- [프론트엔드 아키텍처](#프론트엔드-아키텍처)
- [데이터 플로우](#데이터-플로우)
- [보안 설계](#보안-설계)
- [확장성](#확장성)

---

## 전체 구조

```
┌─────────────────────────────────────────────────────────────┐
│                      사용자 (학생)                           │
│               "자료구조는 몇 학점이야?"                       │
└────────────────────────┬────────────────────────────────────┘
                         │ HTTPS
         ┌───────────────▼───────────────┐
         │    React Frontend             │
         │    (Vite + TypeScript)        │
         │  ┌──────────────────────────┐ │
         │  │  ChatInterface.tsx       │ │
         │  │  - 메시지 렌더링         │ │
         │  │  - 실시간 타이핑         │ │
         │  │  - 지도/테이블 표시      │ │         │  │  Profile.tsx             │ │
         │  │  - 사용자 이름 표시      │ │
         │  │  - AuthContext 통합      │ │         │  └──────────────────────────┘ │
         └───────────────┬───────────────┘
                         │ HTTP/REST
         ┌───────────────▼───────────────┐
         │   FastAPI Backend             │
         │   ┌────────────────────────┐  │
         │   │  main.py               │  │
         │   │  - CORS                │  │
         │   │  - Lifespan 관리       │  │
         │   │  - 라우터 등록         │  │
         │   └────────┬───────────────┘  │
         │            │                   │
         │   ┌────────▼───────────────┐  │
         │   │  /api/chat             │  │
         │   │  (chat router)         │  │
         │   └────────┬───────────────┘  │
         └────────────┼───────────────────┘
                      │
         ┌────────────▼───────────────┐
         │   Agent (agent.py)         │
         │   ┌────────────────────┐   │
         │   │  Claude Sonnet 4   │   │
         │   │  - Tool Selection  │   │
         │   │  - Context Mgmt    │   │
         │   │  - Response Gen    │   │
         │   └────────┬───────────┘   │
         │            │ (최대 5회 반복)│
         │   ┌────────▼───────────┐   │
         │   │  Tool Executor     │   │
         │   │  - process_tool    │   │
         │   │  - 결과 누적       │   │
         │   └────────┬───────────┘   │
         └────────────┼───────────────┘
                      │
         ┌────────────▼───────────────┐
         │   MCP Client               │
         │   (mcp_client.py)          │
         │   ┌────────────────────┐   │
         │   │  - stdio 통신      │   │
         │   │  - 타임아웃 관리   │   │
         │   │  - Lazy start      │   │
         │   │  - 응답 파싱       │   │
         │   └────────┬───────────┘   │
         └────────────┼───────────────┘
                      │ JSON-RPC 2.0
    ┌─────────────────┼─────────────────┐
    │                 │                 │
    ▼                 ▼                 ▼
┌─────────┐     ┌─────────┐     ┌─────────┐
│curriculum│     │ notice  │ ... │ course  │  (9개 MCP 서버)
│  -mcp   │     │  -mcp   │     │  -mcp   │
└────┬────┘     └────┬────┘     └────┬────┘
     │               │               │
     ▼               ▼               ▼
┌──────────────────────────────────────────┐
│   데이터 소스                             │
│   - PostgreSQL                           │
│   - Web Crawling (Playwright, Requests) │
│   - Static JSON                          │
└──────────────────────────────────────────┘
```

---

## Agentic AI 워크플로우

### 핵심 개념

Agent KHU는 **Tool-Use 패턴**을 활용한 **Agentic AI** 시스템입니다.

```python
# agent.py의 핵심 로직
while iteration < max_iterations:
    # 1. Claude에게 메시지 전송
    response = client.messages.create(
        model="claude-sonnet-4-20250514",
        messages=messages,
        tools=tools  # 사용 가능한 Tool 목록
    )
    
    # 2. Claude가 Tool 사용 결정
    if response.stop_reason == "tool_use":
        for content in response.content:
            if content.type == "tool_use":
                # 3. Tool 실행
                result = await process_tool_call(
                    content.name,
                    content.input
                )
                
                # 4. 결과를 Claude에게 다시 전달
                tool_results.append({
                    "type": "tool_result",
                    "tool_use_id": content.id,
                    "content": json.dumps(result)
                })
        
        # 5. 대화 이력 업데이트 (다음 반복에 사용)
        messages.append({"role": "assistant", "content": response.content})
        messages.append({"role": "user", "content": tool_results})
    
    # 6. Claude가 최종 응답 생성
    elif response.stop_reason == "end_turn":
        return final_response
```

### 실행 예시

**사용자 질문**: "자료구조는 몇 학점이고 1학기에 들을 수 있어?"

**Iteration 1**
```
User: "자료구조는 몇 학점이고 1학기에 들을 수 있어?"
    ↓
Claude: [Tool 선택] → search_curriculum(query="자료구조")
    ↓
MCP Client: curriculum-mcp 호출
    ↓
Result: {
    "code": "CSE204",
    "name": "자료구조",
    "credits": 3,
    "semesters": ["1", "2"]
}
    ↓
Claude: [충분한 정보 확보] → end_turn
    ↓
Response: "자료구조는 3학점 과목이며, 1학기와 2학기 모두 수강 가능합니다."
```

**복잡한 질문**: "내일 학식 메뉴 알려주고, 식당 위치도 알려줘"

**Iteration 1**
```
Claude: [Tool 선택] → search_meals(query="내일")
Result: [학식 메뉴 데이터]
```

**Iteration 2**
```
Claude: [추가 Tool 필요] → search_room(query="식당")
Result: [식당 위치 정보]
```

**Iteration 3**
```
Claude: [충분한 정보 확보] → end_turn
Response: "내일 메뉴는... 학생식당은 본관 1층에 있습니다."
```

### 무한 루프 방지

```python
max_iterations = 5  # 최대 5회 반복

if iteration >= max_iterations:
    # 강제 종료 후 현재까지의 정보로 응답 생성
    return fallback_response
```

---

## MCP 프로토콜

### JSON-RPC 2.0 표준

```json
// 요청 (stdin)
{
  "jsonrpc": "2.0",
  "id": 1,
  "method": "tools/call",
  "params": {
    "name": "search_courses",
    "arguments": {"query": "자료구조"}
  }
}

// 응답 (stdout)
{
  "jsonrpc": "2.0",
  "id": 1,
  "result": {
    "content": [
      {
        "type": "text",
        "text": "{\"code\": \"CSE204\", ...}"
      }
    ],
    "isError": false
  }
}
```

### 초기화 시퀀스

```
┌──────────┐                    ┌──────────┐
│  Client  │                    │  Server  │
└─────┬────┘                    └─────┬────┘
      │                               │
      │  initialize                   │
      │─────────────────────────────>│
      │                               │
      │  result (capabilities)        │
      │<─────────────────────────────│
      │                               │
      │  notifications/initialized    │
      │─────────────────────────────>│
      │                               │
      │  (서버 준비 완료)             │
      │                               │
      │  tools/list                   │
      │─────────────────────────────>│
      │                               │
      │  result (tools)               │
      │<─────────────────────────────│
      │                               │
      │  tools/call                   │
      │─────────────────────────────>│
      │                               │
      │  result (data)                │
      │<─────────────────────────────│
```

### Lazy Start

```python
# mcp_client.py
async def _ensure_server(self, server_name: str):
    """서버가 없으면 자동 시작"""
    if server_name not in self.servers:
        path = self.server_paths.get(server_name)
        await self.start_server(server_name, path)
```

**장점**:
- 불필요한 서버는 시작하지 않음
- 메모리 절약
- 시작 시간 단축

---

## 백엔드 아키텍처

### 계층 구조

```
┌────────────────────────────────────┐
│       Presentation Layer           │  (FastAPI Router)
│   - /api/auth                      │
│   - /api/chat                      │
│   - /api/classrooms                │
│   - /api/notices                   │
└───────────┬────────────────────────┘
            │
┌───────────▼────────────────────────┐
│       Business Logic Layer         │
│   - agent.py (AI Agent)            │
│   - mcp_client.py (MCP 통신)       │
│   - crud.py (비즈니스 로직)        │
│   - auth.py (인증/인가)            │
└───────────┬────────────────────────┘
            │
┌───────────▼────────────────────────┐
│       Data Access Layer            │
│   - models.py (SQLAlchemy 모델)   │
│   - database.py (DB 연결)          │
│   - schemas.py (Pydantic 스키마)   │
└───────────┬────────────────────────┘
            │
┌───────────▼────────────────────────┐
│       Data Sources                 │
│   - PostgreSQL                     │
│   - MCP Servers                    │
└────────────────────────────────────┘
```

### 의존성 주입

```python
# FastAPI Depends 패턴
@router.post("/chat")
async def chat_endpoint(
    message: str,
    db: Session = Depends(get_db),           # DB 세션
    current_user: User = Depends(get_current_user)  # 인증된 사용자
):
    result = await chat_with_claude_async(
        message, 
        db, 
        current_user
    )
    return result
```

---

## 프론트엔드 아키텍처

### 컴포넌트 구조

```
App.tsx
 └─ ChatInterface.tsx
     ├─ MessageList
     │   ├─ UserMessage
     │   └─ AssistantMessage
     ├─ InputBox
     ├─ MapView (조건부 렌더링)
     ├─ NoticeList (조건부 렌더링)
     └─ CourseTable (조건부 렌더링)
```

### 상태 관리

```typescript
// ChatInterface.tsx
const [messages, setMessages] = useState<Message[]>([]);
const [inputValue, setInputValue] = useState("");
const [isLoading, setIsLoading] = useState(false);
const [mapData, setMapData] = useState(null);
const [noticeData, setNoticeData] = useState([]);
```

### API 통신

```typescript
// api/chat.ts
export async function sendMessage(message: string): Promise<ChatResponse> {
    const response = await axios.post('/api/chat', {
        message,
        user_latitude: latitude,
        user_longitude: longitude
    });
    
    return response.data;
}
```

---

## 데이터 플로우

### 1. 채팅 메시지 플로우

```
사용자 입력
    ↓
React State 업데이트
    ↓
axios.post('/api/chat')
    ↓
FastAPI /api/chat 엔드포인트
    ↓
agent.chat_with_claude_async()
    ↓
┌─────────────────────┐
│ Agent Loop (최대 5회)│
│  ┌───────────────┐  │
│  │ Claude 호출   │  │
│  │ ↓             │  │
│  │ Tool 선택     │  │
│  │ ↓             │  │
│  │ MCP 호출      │  │
│  │ ↓             │  │
│  │ 결과 누적     │  │
│  │ ↓             │  │
│  │ 재평가        │  │
│  └───────────────┘  │
└─────────────────────┘
    ↓
최종 응답 구성
    ↓
JSON Response
    ↓
React State 업데이트
    ↓
UI 렌더링
```

### 2. MCP 서버 호출 플로우

```python
# agent.py
result = await mcp_client.call_tool(
    "curriculum",           # 서버 이름
    "search_courses",       # Tool 이름
    {"query": "자료구조"}   # 인자
)
    ↓
# mcp_client.py
await _ensure_server("curriculum")  # Lazy start
    ↓
# JSON-RPC 요청 구성
request = {
    "jsonrpc": "2.0",
    "id": 2,
    "method": "tools/call",
    "params": {
        "name": "search_courses",
        "arguments": {"query": "자료구조"}
    }
}
    ↓
# stdio로 전송
process.stdin.write(json.dumps(request) + "\n")
    ↓
# curriculum-mcp/server.py
async def tool_search_courses(args):
    query = args["query"]
    # 크롤링/DB 조회
    return results
    ↓
# JSON-RPC 응답
{
    "jsonrpc": "2.0",
    "id": 2,
    "result": {
        "content": [{"type": "text", "text": "..."}]
    }
}
    ↓
# mcp_client.py: 파싱
parsed = _parse_result_text(response["result"])
    ↓
# agent.py: 결과 누적
accumulated_results["curriculum_courses"].append(parsed)
```

---

## 보안 설계

### 인증 & 인가

```
┌───────────────────────────────────────┐
│  JWT 토큰 기반 인증                   │
├───────────────────────────────────────┤
│  1. 로그인 (POST /api/auth/login)    │
│     └─> JWT 토큰 발급                │
│                                       │
│  2. 보호된 엔드포인트 접근            │
│     └─> Authorization: Bearer TOKEN  │
│     └─> get_current_user() 검증      │
│                                       │
│  3. 토큰 만료 (1시간)                │
│     └─> 재로그인 필요                │
└───────────────────────────────────────┘
```

### 비밀번호 해싱

```python
# auth.py
from passlib.context import CryptContext

pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")

# 해싱
hashed = pwd_context.hash(plain_password)

# 검증
pwd_context.verify(plain_password, hashed_password)
```

### CORS 정책

```python
# main.py
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:5173"],  # 명시적 허용
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)
```

### 환경변수 보호

```python
# .gitignore
.env
*.env
**/.env
```

---

## 확장성

### 1. 새 MCP 서버 추가

```python
# mcp_client.py
self.server_paths.update({
    "new_mcp": self.mcp_dir / "new-mcp/server.py"
})

# agent.py
tools.append({
    "name": "new_tool",
    "description": "...",
    "input_schema": {...}
})
```

### 2. 새 API 엔드포인트

```python
# routers/new_router.py
@router.get("/new")
async def new_endpoint():
    return {"message": "new"}

# main.py
app.include_router(new_router)
```

### 3. 수평 확장

```
                  ┌──────────────┐
                  │ Load Balancer│
                  └──────┬───────┘
         ┌───────────────┼───────────────┐
         ▼               ▼               ▼
    ┌────────┐      ┌────────┐      ┌────────┐
    │Backend1│      │Backend2│      │Backend3│
    └────┬───┘      └────┬───┘      └────┬───┘
         └───────────────┼───────────────┘
                         ▼
                 ┌───────────────┐
                 │  PostgreSQL   │
                 │  (Primary +   │
                 │   Replicas)   │
                 └───────────────┘
```

**주의사항**:
- MCP 서버는 각 백엔드 인스턴스에서 독립 실행
- DB 커넥션 풀 적절히 설정
- 세션 스토어 고려 (Redis 등)

---

## 성능 최적화

### 1. MCP 서버 캐싱

```python
# curriculum-mcp/server.py
CACHE_PATH = Path(__file__).parent / "data/curriculum_data.json"

def load_data():
    if CACHE_PATH.exists():
        with open(CACHE_PATH) as f:
            return json.load(f)
    # 크롤링...
```

### 2. DB 인덱스

```python
# models.py
class Notice(Base):
    __table_args__ = (
        Index('idx_notice_search', 'title', 'content'),
        Index('idx_notice_date', 'date'),
    )
```

### 3. 비동기 처리

```python
# agent.py
async def chat_with_claude_async(...):
    # 모든 I/O 작업 비동기
    result = await mcp_client.call_tool(...)
```

---

## 다음 단계

- [MCP 서버 개발 가이드](MCP_SERVERS.md)
- [API 문서](API.md)
- [배포 가이드](DEPLOYMENT.md)